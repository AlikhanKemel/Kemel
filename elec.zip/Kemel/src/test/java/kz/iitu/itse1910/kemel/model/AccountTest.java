package kz.iitu.itse1910.kemel.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

class AccountTest {
    @Mock
    Customer customer;
    @Mock
    Company company;
    @InjectMocks
    Account account;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSetAccountId() {
        account.setAccountId(Integer.valueOf(0));
    }

    @Test
    void testSetAccountName() {
        account.setAccountName("accountName");
    }

    @Test
    void testSetCustomer() {
        account.setCustomer(new Customer(Integer.valueOf(0), "customerName", "customerEmail", "customerAdress"));
    }

    @Test
    void testSetCompany() {
        account.setCompany(new Company(Integer.valueOf(0), "companyName", "companyAdress"));
    }


}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme