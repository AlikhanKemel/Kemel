package kz.iitu.itse1910.kemel.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AdminTest {
    Admin admin = new Admin(Integer.valueOf(0), "adminName", "adminPassword");

    @Test
    void testSetAdmin_id() {
        admin.setAdmin_id(Integer.valueOf(0));
    }

    @Test
    void testSetAdminName() {
        admin.setAdminName("adminName");
    }

    @Test
    void testSetAdminPassword() {
        admin.setAdminPassword("adminPassword");
    }




}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme