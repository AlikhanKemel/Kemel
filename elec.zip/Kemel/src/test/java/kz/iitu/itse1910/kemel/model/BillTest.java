package kz.iitu.itse1910.kemel.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

class BillTest {
    @Mock
    Invoice invoice;
    @Mock
    Account account;
    @InjectMocks
    Bill bill;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSetBillId() {
        bill.setBillId(Integer.valueOf(0));
    }

    @Test
    void testSetPaymentDate() {
        bill.setPaymentDate("paymentDate");
    }

    @Test
    void testSetBillStatus() {
        bill.setBillStatus("billStatus");
    }

    @Test
    void testSetInvoice() {
        bill.setInvoice(new Invoice(Integer.valueOf(0), Long.valueOf(1), Long.valueOf(1), new Electricity(Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0)), new Tarrif(Integer.valueOf(0), "tarrifType", Integer.valueOf(0), new Category(Integer.valueOf(0), "categoryName"))));
    }

    @Test
    void testSetAccount() {
        bill.setAccount(new Account(Integer.valueOf(0), "accountName", new Customer(Integer.valueOf(0), "customerName", "customerEmail", "customerAdress"), new Company(Integer.valueOf(0), "companyName", "companyAdress")));
    }

}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme