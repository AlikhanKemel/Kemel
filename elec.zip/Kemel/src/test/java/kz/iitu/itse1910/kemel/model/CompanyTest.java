package kz.iitu.itse1910.kemel.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CompanyTest {
    Company company = new Company(Integer.valueOf(0), "companyName", "companyAdress");

    @Test
    void testSetCompanyId() {
        company.setCompanyId(Integer.valueOf(0));
    }

    @Test
    void testSetCompanyName() {
        company.setCompanyName("companyName");
    }

    @Test
    void testSetCompanyAdress() {
        company.setCompanyAdress("companyAdress");
    }




}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme