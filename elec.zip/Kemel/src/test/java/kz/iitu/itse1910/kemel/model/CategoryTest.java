package kz.iitu.itse1910.kemel.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CategoryTest {
    Category category = new Category(Integer.valueOf(0), "categoryName");

    @Test
    void testSetCategoryId() {
        category.setCategoryId(Integer.valueOf(0));
    }

    @Test
    void testSetCategoryName() {
        category.setCategoryName("categoryName");
    }




}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme