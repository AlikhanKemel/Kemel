package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Feedback;
import kz.iitu.itse1910.kemel.model.Tarrif;
import kz.iitu.itse1910.kemel.repository.FeedbackRepo;
import kz.iitu.itse1910.kemel.repository.TarrifRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service


public class FeedbackService {

        @Autowired
        private JdbcTemplate jdbcTemplate;

        @Autowired
        private FeedbackRepo feedbackRepo;
        public FeedbackService(FeedbackRepo feedbackRepo){
            this.feedbackRepo=feedbackRepo;
        }

        public List<Feedback> findAll(){
            return feedbackRepo.findAll();
        }
        public String deleteById(Integer feedbackId) {
            return feedbackRepo.deleteById(feedbackId)+" ";
        }
}
