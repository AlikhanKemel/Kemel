package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Customer;
import kz.iitu.itse1910.kemel.repository.CustomerRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class CustomerService  {
   @Autowired
   private CustomerRepo customerRepo;


    public List<Customer> findAll() {
        return customerRepo.findAll();
    }
    public Customer findById( Integer customerId) {
        return customerRepo.findById(customerId);
    }
    public String save(Customer customer) {
        return customerRepo.save(customer)+" Customer(s) saved successfully";
    }
    public String deleteById(Integer customerId) {
        return customerRepo.deleteById(customerId)+" Employee(s) delete from the database";
    }
    public String update( Customer customer,  Integer customer_id) {
        return customerRepo.update(customer, customer_id)+" Employee(s) updated successfully";
    }
    @Scheduled( fixedRateString  = "${fixedRate.in.seconds}")
    public void scheduleFixedDelayTasks()throws InterruptedException {
        log.info(
                "Fixed Delay - " +customerRepo.findAll());
    }
}
