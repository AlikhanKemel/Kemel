package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Account;

import kz.iitu.itse1910.kemel.model.Feedback;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class FeedBackRepoImpl implements  FeedbackRepo{
@Autowired
private JdbcTemplate jdbcTemplate;
    @Override
    public List<Feedback> findAll() {
        List<Feedback> feedbacks = this.jdbcTemplate.query("SELECT * FROM feedback  ", new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Feedback feedback = new Feedback();
                Account account = jdbcTemplate.queryForObject("SELECT * FROM account WHERE account_id=?", new BeanPropertyRowMapper<Account>(Account.class), rs.getInt("account_id"));

                feedback.setAccount(account);
                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setFeedbackText(rs.getString("feedback_text"));

                return feedback;

            }
        });



        return feedbacks;
    }

    @Override
    public Integer deleteById(Integer feedbackId) {
        return jdbcTemplate.update("DELETE FROM feedbcak WHERE feedback_id=?", feedbackId);
    }
}
