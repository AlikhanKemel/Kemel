package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Bill;
import kz.iitu.itse1910.kemel.model.Tarrif;
import kz.iitu.itse1910.kemel.repository.BillRepo;
import kz.iitu.itse1910.kemel.repository.TarrifRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TarrifService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private TarrifRepo tarrifRepo;
    public TarrifService(TarrifRepo tarrifRepo){
        this.tarrifRepo=tarrifRepo;
    }

    public List<Tarrif> findAll(){
        return tarrifRepo.findAll();
    }
    public String deleteById(Integer tarrifId) {
        return tarrifRepo.deleteById(tarrifId)+" ";
    }
}
