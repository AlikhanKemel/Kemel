package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Customer;
import kz.iitu.itse1910.kemel.model.Electricity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ElectricityRepoImpl implements ElectricityRepo{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public Electricity findById(Integer electricityId) {
        return jdbcTemplate.queryForObject("SELECT * FROM electricity_board WHERE electricity_id=?", new BeanPropertyRowMapper<Electricity>(Electricity.class), electricityId);
    }

    @Override
    public int save(Electricity electricity) {
        return jdbcTemplate.update("INSERT INTO electricity_board (meter_reading, meter_reading_old) VALUES (?, ?)", new Object[] {electricity.getMeterReading(), electricity.getMeterReadingOld()});
    }

    @Override
    public int deleteById(Integer electricityId) {
        return jdbcTemplate.update("DELETE FROM electricity_board WHERE electricity_id=?", electricityId);
    }
    @Override
    public int update(Electricity electricity, Integer electricityId) {
        return jdbcTemplate.update("UPDATE electricity_board SET meter_reading=?, meter_reading_old=? WHERE electricity_id = ?", new Object[] {electricity.getMeterReading(), electricity.getMeterReadingOld(), electricityId});
    }
}
