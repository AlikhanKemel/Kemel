package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.FeedbackService;
import kz.iitu.itse1910.kemel.Service.TarrifService;
import kz.iitu.itse1910.kemel.model.Feedback;
import kz.iitu.itse1910.kemel.model.Tarrif;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {
    @Autowired
    FeedbackService feedbackService;
    @GetMapping("/all")
    public List<Feedback> findAll(){
        return feedbackService.findAll();
    }
    @DeleteMapping("/delete/{feedbackId}")
    public String deleteById(@PathVariable Integer feedbackId) {
        return feedbackService.deleteById(feedbackId)+" Feedback delete from the database";
    }
}
