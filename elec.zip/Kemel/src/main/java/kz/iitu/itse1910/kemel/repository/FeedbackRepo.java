package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Feedback;


import java.util.List;

public interface FeedbackRepo {
    List<Feedback> findAll();
    public Integer deleteById(Integer feedbackId);
}
