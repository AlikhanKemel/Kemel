package kz.iitu.itse1910.kemel.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
@Lazy
public class InvoiceService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public Integer Unit(Integer electricityId){
        Integer value1, value2,value3;
        value1=jdbcTemplate.queryForObject("SELECT meter_reading FROM electricity_board WHERE electricity_id=?", new Object[] {electricityId},Integer.class);
        value2=jdbcTemplate.queryForObject("SELECT meter_reading_old FROM electricity_board WHERE electricity_id=?", new Object[] {electricityId},Integer.class);
        value3=value1-value2;


        return   jdbcTemplate.update(
                "UPDATE invoice Set unit_consumption=? where invoice_id=?",
                value3,electricityId
        );
    }
    public Integer Price(Integer invoice_id,Integer tarrif_id){
        Integer value1, value2,value3;
        value1=jdbcTemplate.queryForObject("SELECT tarrif_price FROM tarrif WHERE tarrif_id=?", new Object[] {tarrif_id},Integer.class);
        value2=jdbcTemplate.queryForObject("SELECT unit_consumption FROM invoice WHERE invoice_id=?", new Object[] {invoice_id},Integer.class);
        value3=value1*value2;


        return   jdbcTemplate.update(
                "UPDATE invoice Set payment_amount=? where invoice_id=?",
                value3,invoice_id
        );
    }

}
