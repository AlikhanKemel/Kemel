package kz.iitu.itse1910.kemel.repository;


import kz.iitu.itse1910.kemel.model.Bill;
import kz.iitu.itse1910.kemel.model.Company;

import java.util.List;

public interface BillRepo {
    List<Bill> findAll();
    public Integer deleteById(Integer billId);
    
}
