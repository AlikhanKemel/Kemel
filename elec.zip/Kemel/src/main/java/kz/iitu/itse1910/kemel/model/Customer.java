package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name="customer_name")
    private String customerName;
    @Column(name="customer_email")
    private String customerEmail;
    @Column(name="customer_adress")
    private String customerAdress;


}
