package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="electricity_board")
public class Electricity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "electricity_id")
    private Integer electricityId;
    @Column(name = "meter_reading")
    private Integer meterReading;
    @Column(name = "meter_reading_old")
    private Integer meterReadingOld;


}
