package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Account;


import java.util.List;

public interface AccountRepo  {
    List<Account> findAll();
    public Integer deleteById(Integer accountId);
}
