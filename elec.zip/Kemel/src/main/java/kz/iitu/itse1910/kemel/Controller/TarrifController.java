package kz.iitu.itse1910.kemel.Controller;


import kz.iitu.itse1910.kemel.Service.TarrifService;
;
import kz.iitu.itse1910.kemel.model.Tarrif;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarrif")
public class TarrifController {
    @Autowired
    TarrifService tarrifService;
    @GetMapping("/all")
    public List<Tarrif> findAll(){
        return tarrifService.findAll();
    }
    @DeleteMapping("/delete/{tarrifId}")
    public String deleteById(@PathVariable Integer tarrifId) {
        return tarrifService.deleteById(tarrifId)+" Bill delete from the database";
    }
}
