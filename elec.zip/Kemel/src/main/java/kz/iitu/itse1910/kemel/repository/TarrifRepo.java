package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Account;
import kz.iitu.itse1910.kemel.model.Tarrif;

import java.util.List;

public interface TarrifRepo {
    List<Tarrif> findAll();
    public Integer deleteById(Integer tarrifId);
}
