package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="bill")
public class Bill {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="bill_id")
    private Integer billId;
    @Column(name = "payment_date")
    private String paymentDate;
    @Column(name = "bill_status")
    private String billStatus;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "invoice_id",referencedColumnName = "invoice_id")
    private Invoice invoice;
    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
}
