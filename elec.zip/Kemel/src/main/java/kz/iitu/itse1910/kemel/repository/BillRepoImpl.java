package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class BillRepoImpl implements BillRepo {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<Bill> findAll() {
        List<Bill> bills = this.jdbcTemplate.query("SELECT * FROM bill  ", new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Bill bill = new Bill();
                Invoice invoice = jdbcTemplate.queryForObject("SELECT * FROM Invoice WHERE invoice_id=?", new BeanPropertyRowMapper<Invoice>(Invoice.class), rs.getInt("invoice_id"));
                Account account = jdbcTemplate.queryForObject("SELECT * FROM Account WHERE account_id=?", new BeanPropertyRowMapper<Account>(Account.class), rs.getInt("account_id"));

                bill.setBillId(rs.getInt("bill_id"));
                bill.setBillStatus(rs.getString("bill_status"));
                bill.setAccount(account);
                bill.setInvoice(invoice);
                bill.setPaymentDate(rs.getString("payment_date"));
                return bill;

            }
            });



        return bills;
    }

    @Override
    public Integer deleteById(Integer billId) {
        return jdbcTemplate.update("DELETE FROM Bill WHERE bill_id=?", billId);
    }


}




