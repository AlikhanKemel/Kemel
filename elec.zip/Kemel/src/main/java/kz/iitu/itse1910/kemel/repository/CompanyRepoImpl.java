package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CompanyRepoImpl implements CompanyRepo{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Company> findAll() {
        return jdbcTemplate.query("SELECT * from Electricity_supply_company", BeanPropertyRowMapper.newInstance(Company.class));
    }
    @Override
    public Company findById(Integer companyId) {
        return jdbcTemplate.queryForObject("SELECT * FROM electricity_supply_company WHERE company_id=?", new BeanPropertyRowMapper<Company>(Company.class), companyId);
    }

    @Override
    public Integer save(Company company) {
        return jdbcTemplate.update("INSERT INTO electricity_supply_company (company_name, company_adress) VALUES (?, ?)", new Object[] {company.getCompanyName(), company.getCompanyAdress()});
    }

    @Override
    public Integer deleteById(Integer companyId) {
        return jdbcTemplate.update("DELETE FROM electricity_supply_company WHERE company_id=?", companyId);
    }
    @Override
    public Integer update(Company company, Integer companyId) {
        return jdbcTemplate.update("UPDATE electricity_supply_company SET company_name = ?, company_adress = ? WHERE company_id = ?", new Object[] {company.getCompanyName(), company.getCompanyAdress(), companyId});
    }
}
