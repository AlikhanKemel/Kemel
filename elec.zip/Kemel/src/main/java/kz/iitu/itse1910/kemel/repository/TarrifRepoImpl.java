package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class TarrifRepoImpl implements TarrifRepo{
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Override
    public List<Tarrif> findAll() {
        List<Tarrif> tarrifs = this.jdbcTemplate.query("SELECT * FROM tarrif  ", new RowMapper() {
        @Override
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            Tarrif tarrif = new Tarrif();
            Category category = jdbcTemplate.queryForObject("SELECT * FROM category WHERE category_id=?", new BeanPropertyRowMapper<Category>(Category.class), rs.getInt("category_id"));

            tarrif.setCategory(category);
            tarrif.setTarrifId(rs.getInt("tarrif_id"));
            tarrif.setTarrifType(rs.getString("tarrif_type"));
            tarrif.setTarrifPrice(rs.getInt("tarrif_price"));

            return tarrif;

        }
    });



        return tarrifs;
    }

    @Override
    public Integer deleteById(Integer tarrifId) {
        return jdbcTemplate.update("DELETE FROM tarrif WHERE tarrif_id=?", tarrifId);
    }
}
