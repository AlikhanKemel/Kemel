package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Account;
import kz.iitu.itse1910.kemel.model.Company;
import kz.iitu.itse1910.kemel.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class AccountImpl implements AccountRepo{

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Account> findAll() {


        List<Account> accounts=this.jdbcTemplate.query("SELECT * FROM Account ",new RowMapper(){
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                Account account=new Account();
                Customer customer= jdbcTemplate.queryForObject("SELECT * FROM Customer WHERE customer_id=?", new BeanPropertyRowMapper<Customer>(Customer.class), rs.getInt("customer_id"));
                Company company= jdbcTemplate.queryForObject("SELECT * FROM Electricity_supply_company WHERE company_id=?", new BeanPropertyRowMapper<Company>(Company.class), rs.getInt("company_id"));
                account.setAccountId(rs.getInt("account_id"));
                account.setAccountName(rs.getString("account_name"));
                account.setCustomer(customer);
                account.setCompany(company);
                return account;
            }


        });
        return accounts;

    }

    @Override
    public Integer deleteById(Integer accountId) {
        return jdbcTemplate.update("DELETE FROM Account WHERE account_id=?", accountId);
    }
}
