package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.AccountService;
import kz.iitu.itse1910.kemel.model.Account;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
public class AccountController {
    @Autowired
    private AccountService accountService;


    @GetMapping("/all")
    public List<Account> findAll() {

        return  accountService.getAllAccount();
    }
    @DeleteMapping("/delete/{accountId}")
    public String deleteById(@PathVariable Integer accountId) {
        return accountService.deleteById(accountId)+" Account delete from the database";
    }
    }