package kz.iitu.itse1910.kemel.Controller;


import kz.iitu.itse1910.kemel.Service.ElectricityService;

import kz.iitu.itse1910.kemel.model.Electricity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/electricity")
public class ElectricityController {
    @Autowired
    private ElectricityService electricityService;
    @GetMapping("{electricityId}")
    public ResponseEntity<String> getCustomer(@PathVariable Integer electricityId) {
        Electricity electricity=electricityService.findById(electricityId);
        if(electricity==null){
            return new ResponseEntity<>("Electricity dont find", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else return new ResponseEntity<>(" "+electricity,HttpStatus.OK);
    }
    @PostMapping("/create")
    public String save(@RequestBody Electricity electricity) {
        return electricityService.save(electricity)+" Electriciry saved successfully";
    }
    @DeleteMapping("/delete/{electricityId}")
    public String deleteById(@PathVariable Integer electricityId) {
        return electricityService.deleteById(electricityId)+"  delete from the database";
    }
    @PutMapping("/update/{electricityId}")
    public String update(@RequestBody Electricity electricity, @PathVariable  Integer electricityId) {
        return electricityService.update(electricity,electricityId)+"  updated successfully";
    }


}
