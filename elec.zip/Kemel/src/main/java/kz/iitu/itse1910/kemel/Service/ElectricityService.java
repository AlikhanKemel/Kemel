package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Customer;
import kz.iitu.itse1910.kemel.model.Electricity;
import kz.iitu.itse1910.kemel.repository.ElectricityRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ElectricityService {
    @Autowired
    private ElectricityRepo electricityRepo;
    public Electricity findById(Integer electricityId) {
        return electricityRepo.findById(electricityId);
    }
    public String save(Electricity electricity) {
        return electricityRepo.save(electricity)+" ";
    }
    public String deleteById(Integer electricityId) {
        return electricityRepo.deleteById(electricityId)+" ";
    }
    public String update( Electricity electricity,  Integer electricityId) {
        return electricityRepo.update(electricity, electricityId)+" ";
    }
}
