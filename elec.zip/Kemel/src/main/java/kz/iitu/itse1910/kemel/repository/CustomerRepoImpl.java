package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class CustomerRepoImpl implements CustomerRepo {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public List<Customer> findAll() {
        return jdbcTemplate.query("SELECT * from Customer", BeanPropertyRowMapper.newInstance(Customer.class));
    }
    @Override
    public Customer findById(Integer customerId) {
        return jdbcTemplate.queryForObject("SELECT * FROM Customer WHERE customer_id=?", new BeanPropertyRowMapper<Customer>(Customer.class), customerId);
    }

    @Override
    public int save(Customer customer) {
        return jdbcTemplate.update("INSERT INTO Customer (customer_name, customer_email, customer_adress) VALUES (?, ?, ?)", new Object[] {customer.getCustomerName(), customer.getCustomerEmail(), customer.getCustomerAdress()});
    }

    @Override
    public int deleteById(Integer customerId) {
        return jdbcTemplate.update("DELETE FROM Customer WHERE customer_id=?", customerId);
    }
    @Override
    public int update(Customer customer, Integer customerId) {
        return jdbcTemplate.update("UPDATE Customer SET customer_name = ?, customer_email = ?, customer_adress = ? WHERE customer_id = ?", new Object[] {customer.getCustomerName(), customer.getCustomerEmail(), customer.getCustomerAdress(), customerId});
    }
}
