package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tarrif")
public class Tarrif {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="tarrif_id")
    private Integer tarrifId;
    @Column(name = "tarrif_type")
    private String tarrifType;
    @Column(name = "tarrif_price")
    private Integer tarrifPrice;
    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;
}
