package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.CustomerService;
import kz.iitu.itse1910.kemel.model.Customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

;
import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
     private CustomerService customerService;

    @GetMapping("/all")
    public List<Customer> findAll() {
        return customerService.findAll();
    }
    @GetMapping("{customer_id}")
    public ResponseEntity<String> getCustomer(@PathVariable (value = "customer_id")Integer customerId) {
        Customer customer=customerService.findById(customerId);
        if(customer==null){
            return new ResponseEntity<>("Customer dont find", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else return new ResponseEntity<>(" "+customer,HttpStatus.OK);
    }
    @PostMapping("/create")
    public String save(@RequestBody Customer customer) {
        return customerService.save(customer)+" customer saved successfully";
    }
    @DeleteMapping("/delete/{customerId}")
    public String deleteById(@PathVariable Integer customerId) {
        return customerService.deleteById(customerId)+" customer delete from the database";
    }
    @PutMapping("/update/{customerId}")
    public String update(@RequestBody Customer customer, @PathVariable  Integer customerId) {
        return customerService.update(customer, customerId)+"  updated successfully";
    }

    @RequestMapping(value = "/{customerId}", method = RequestMethod.HEAD)
    public Customer getHead(@PathVariable Integer customerId) {
        return customerService.findById(customerId);


    }
}
