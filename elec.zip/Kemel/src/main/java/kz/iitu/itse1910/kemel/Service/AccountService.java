package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Account;
import kz.iitu.itse1910.kemel.model.Customer;
import kz.iitu.itse1910.kemel.repository.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    private  AccountRepo accountRepo;

    public AccountService(AccountRepo accountRepo){
        this.accountRepo=accountRepo;
    }
 public List<Account> getAllAccount()
    {
     return accountRepo.findAll();
    }
    public String deleteById(Integer accountId) {
        return accountRepo.deleteById(accountId)+" ";
    }
}
