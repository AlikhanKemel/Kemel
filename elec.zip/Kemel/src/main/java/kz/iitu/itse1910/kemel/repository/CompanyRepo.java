package kz.iitu.itse1910.kemel.repository;


import kz.iitu.itse1910.kemel.model.Company;


import java.util.List;

public interface CompanyRepo {
    List<Company> findAll();
    public Company findById(Integer customerId);

    public Integer save(Company company);
    public Integer deleteById(Integer companyId);
    public Integer update(Company company, Integer companyId);
}
