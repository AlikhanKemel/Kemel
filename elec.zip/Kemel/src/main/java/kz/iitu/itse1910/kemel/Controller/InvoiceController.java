package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.InvoiceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/invoice")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;
    @GetMapping("/all/{electricityId}")
    public Integer Unit( @PathVariable Integer electricityId){

        return invoiceService.Unit(electricityId);
    }
    @GetMapping("/pay/{invoiceId}/{tarrifId}")
        public Integer Price(@PathVariable Integer invoiceId,@PathVariable Integer tarrifId){
            return invoiceService.Price(invoiceId,tarrifId);
        }

    }

