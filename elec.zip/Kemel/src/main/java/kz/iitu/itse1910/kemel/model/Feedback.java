package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="feedback")
public class Feedback {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "feedback_id")
    private Integer feedbackId;
    @Column(name = "feedback_text")
    private String feedbackText;

    @ManyToOne
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;
}
