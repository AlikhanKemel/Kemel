package kz.iitu.itse1910.kemel.repository;


import kz.iitu.itse1910.kemel.model.Electricity;

public interface ElectricityRepo {
    public Electricity findById(Integer electricityId);

    public int save(Electricity electricity);
    public int deleteById(Integer electricityId);
    public int update(Electricity electricity, Integer electricityId);
}
