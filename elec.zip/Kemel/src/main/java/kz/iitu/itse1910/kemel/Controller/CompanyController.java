package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.CompanyService;

import kz.iitu.itse1910.kemel.model.Company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/company")
public class CompanyController {
    @Autowired
    private CompanyService companyService;
    @GetMapping("/all")
    public List<Company> findAll() {

        return  companyService.findAll();
    }
    @GetMapping("{companyId}")
    public ResponseEntity<String> getComapny(@PathVariable Integer companyId) {
        Company company=companyService.findById(companyId);
        if(company==null){
            return new ResponseEntity<>(" ", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else return new ResponseEntity<>(" "+company,HttpStatus.OK);
    }
    @PostMapping("/create")
    public String save(@RequestBody Company company) {
        return companyService.save(company)+" ";
    }
    @DeleteMapping("/delete/{companyId}")
    public String deleteById(@PathVariable Integer companyId) {
        return companyService.deleteById(companyId)+" ";
    }
    @PutMapping("/update/{companyId}")
    public String update(@RequestBody Company company, @PathVariable  Integer companyId) {
        return companyService.update(company, companyId)+"  ";
    }



}
