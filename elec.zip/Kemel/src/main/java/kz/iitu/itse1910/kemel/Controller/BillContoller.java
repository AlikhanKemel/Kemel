package kz.iitu.itse1910.kemel.Controller;

import kz.iitu.itse1910.kemel.Service.BillService;
import kz.iitu.itse1910.kemel.model.Bill;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/bill")
public class BillContoller {
    @Autowired
    BillService billServiceRepo;
    @GetMapping("/all")
    public List<Bill> findAll(){
        return billServiceRepo.findAll();
    }
    @DeleteMapping("/delete/{billId}")
    public String deleteById(@PathVariable Integer billId) {
        return billServiceRepo.deleteById(billId)+" Bill delete from the database";
    }
}

