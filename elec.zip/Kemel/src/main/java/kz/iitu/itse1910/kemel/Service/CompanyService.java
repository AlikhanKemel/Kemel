package kz.iitu.itse1910.kemel.Service;

import kz.iitu.itse1910.kemel.model.Company;
import kz.iitu.itse1910.kemel.model.Customer;
import kz.iitu.itse1910.kemel.repository.CompanyRepo;
import kz.iitu.itse1910.kemel.repository.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyService {
    @Autowired
    private CompanyRepo companyRepo;


    public List<Company> findAll() {
        return companyRepo.findAll();
    }
    public Company findById( Integer companyId) {
        return companyRepo.findById(companyId);
    }
    public String save(Company company) {
        return companyRepo.save(company)+" Company saved successfully";
    }
    public String deleteById(Integer companyId) {
        return companyRepo.deleteById(companyId)+" Company delete from the database";
    }
    public String update( Company company,  Integer companyId) {
        return companyRepo.update(company, companyId)+" Company updated successfully";
    }
}
