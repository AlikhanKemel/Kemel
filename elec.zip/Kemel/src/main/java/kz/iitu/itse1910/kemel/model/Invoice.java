package kz.iitu.itse1910.kemel.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="invoice")
public class Invoice {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "invoice_id")
    private Integer invoiceId;
    @Column(name = "unit_consumption")
    private Long unitConsumption;
    @Column(name = "payment_amount")
    private Long paymentAmount;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "electricity_id",referencedColumnName = "electricity_id")
    private Electricity electricity;

    @ManyToOne
    @JoinColumn(name = "tarrif_id", nullable = false)
    private Tarrif tarrif;
}
