package kz.iitu.itse1910.kemel.Aop;

import kz.iitu.itse1910.kemel.CustomHundler.TaskException;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

@Component
@Aspect
@Slf4j
public class AopAspect {
    @Before(value = "execution(* kz.iitu.itse1910.kemel.Controller.*.*(..))")
    public void logStatementBefore(JoinPoint joinPoint) {
        log.info("Executing {}",joinPoint);
    }
    @After(value = "execution(* kz.iitu.itse1910.kemel.Controller.*.*(..))")
    public void logStatementAfter(JoinPoint joinPoint) {
        log.info("Complete exceution of {}",joinPoint);
    }
    @Around(value = "execution(* kz.iitu.itse1910.kemel.Service.*.*(..))")
    public Object taskHandler(ProceedingJoinPoint joinPoint) throws Throwable {

        try {
            Object obj=joinPoint.proceed();
            return obj;
        }
        catch(TaskException e) {
            log.info(" TaskException StatusCode {}",e.getHttpStatus().value());
            log.info("TaskException Message {}",e.getMessage());
            throw new ResponseStatusException(e.getHttpStatus(), e.getMessage());
        }
    }

}
