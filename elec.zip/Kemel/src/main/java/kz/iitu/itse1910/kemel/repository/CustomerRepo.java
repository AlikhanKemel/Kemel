package kz.iitu.itse1910.kemel.repository;

import kz.iitu.itse1910.kemel.model.Customer;


import java.util.List;

public interface CustomerRepo {
    List<Customer> findAll();
    public Customer findById(Integer customerId);

    public int save(Customer customer);
    public int deleteById(Integer customerId);
    public int update(Customer customer, Integer customerId);
}
